import json
# import boto3
# from smart_open import open
from collections import defaultdict
# s3 = boto3.resource('s3')
# bucket = s3.Bucket('nj-transit-app')

    # 40570, 38174
def lambda_handler(event, context):
    destination = event['destination']
    origin = event['origin']
    # results = stops(destination, origin)
    return {
        'statusCode': 200,
        'body': json.dumps(["results"])
    }

routes = {}
stops = {}
trips = {}
stop_times = {}

def load_files():  
  with open("s3://nj-transit-app/routes.txt") as file:
    line_index = 0
    for line in file:
      if line_index > 0:
        data = line.split(',')
        routes[line_index] = {
          'route_id': int(data[0]),
          'agency_id': data[1].replace('"', ''),
          'route_short_name': data[2].replace('"', ''),
          'route_long_name': data[3].replace('"', ''),
          'route_type': int(data[4]),
          'route_url': data[5].replace('"', ''),
          'route_colour': data[6].replace('\n', '')
        } 
        # print(routes[line_index])
      line_index += 1

  with open('s3://nj-transit-app/stops.txt', 'rb') as file:
    line_index = 0
    for line in file:
      if line_index > 0:
        data = line.split(',')
        stops[line_index] = {
          'stop_id': int(data[0]),
          'stop_code': int(data[1]),
          'stop_name': data[2].replace('"', ''),
          'stop_desc': data[3].replace('"', ''),
          'stop_lat': float(data[4]),
          'stop_lon': float(data[5]),
          'zone_id': data[6].replace('\n', '')
        } 
        # print(stops[line_index])
      line_index += 1



  with open("s3://nj-transit-app//trips.txt") as file:
    line_index = 0
    for line in file:
      if line_index > 0:
        data = line.split(',')
        trips[line_index] = {
          'route_id': int(data[0]),
          'service_id': int(data[1]),
          'trip_id': int(data[2]),
          'trip_headsign': data[3].replace('"', ''),
          'direction_id': int(data[4]),
          'block_id': data[5].replace('"', ''),
          'shape_id': int(data[6])
        } 
        # print(trips[line_index])
      line_index += 1

  with open("s3://nj-transit-app/stop_times.txt") as file:
    line_index = 0
    for line in file:
      if line_index > 0:
        data = line.split(',')
        stop_times[line_index] = {
          'trip_id': int(data[0]),
          'arrival_time': data[1],
          'departure_time': data[2],
          'stop_id': int(data[3]),
          'stop_sequence': int(data[4]),
          'pickup_type': int(data[5]),
          'drop_off_type': int(data[6]),
          'shape_dist_traveled': float(data[7])
        } 
        # print(stop_times[line_index])
      line_index += 1

def find_stops (origin, destination):
  filtered = {}
  destination_trips = defaultdict(list)
  for id, stop in stop_times.items():
    if stop['stop_id'] == destination:
      destination_trips[stop['trip_id']].append(id)
  for id, stop in stop_times.items():
    if (stop['stop_id'] == origin):
      if destination_trips[stop['trip_id']]:
        filtered[id] = stop
  return filtered


